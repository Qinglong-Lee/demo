package tmp;

public class SimpleClass {
}
